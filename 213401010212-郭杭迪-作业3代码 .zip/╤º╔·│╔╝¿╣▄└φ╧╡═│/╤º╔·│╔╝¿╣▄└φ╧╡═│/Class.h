#pragma once
#ifndef CLASS_H
#define CLASS_H

#include "Student.h"

class Class {
private:
    int n;
    Student* p;

public:
    Class();
    ~Class();

    void start();
    Student* set();
    void Show_set_result();
    void Add_student();
    void Delete_student();
    void Revise_student();
    void Inquiry_student();
    void Show_menu();
    void Show_student();
    void Show_student(int a);
    void Average_grade();
    void Average_grade(int a);
    void Best_grade();
    void Best_grade(int a);
    void Worst_grade();
    void Worst_grade(int a);
    void Out();
};

#endif // CLASS_H
