#pragma once
#ifndef STUDENT_H
#define STUDENT_H

#include <string>
using namespace std;

class Student {
public:
    string name;
    int s_num;
    double grade_1, grade_2;
    Student* next=NULL;

    Student();
    ~Student();
};

#endif // STUDENT_H
