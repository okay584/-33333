#include "Student.h"

Student::Student() {
    name = "";
    s_num = 0;
    grade_1 = 0;
    grade_2 = 0;
    next = nullptr;
}

Student::~Student() {
    // Destructor implementation, if needed
}
